# Cleanup script 
Remove-Item C:\temp\*.tmp 
