var searchData=
[
  ['adderror_0',['addError',['../class_report.html#a3503fac691eb4ce848ac59f0eee09941',1,'Report']]],
  ['addfileprocessed_1',['addFileProcessed',['../class_report.html#af36d9a9fd37cbde87550a41bf2876fe2',1,'Report']]],
  ['addhealthy_2',['addHealthy',['../class_report.html#a2e4adab93eb5758c01c7e9b15189ae49',1,'Report']]],
  ['addinfected_3',['addInfected',['../class_report.html#aac946350c5a68eabb8cde30e71e34c52',1,'Report']]]
];
