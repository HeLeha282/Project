var searchData=
[
  ['_7elogger_0',['~Logger',['../class_logger.html#acb668a9e186a25fbaad2e4af6d1ed00a',1,'Logger']]]
];
