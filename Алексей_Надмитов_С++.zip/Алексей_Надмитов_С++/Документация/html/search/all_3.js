var searchData=
[
  ['getverdict_0',['getVerdict',['../class_database.html#afc9872234bd7addf49c8f408936318ff',1,'Database']]]
];
