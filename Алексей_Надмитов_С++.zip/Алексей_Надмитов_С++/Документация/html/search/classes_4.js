var searchData=
[
  ['logger_0',['Logger',['../class_logger.html',1,'']]]
];
