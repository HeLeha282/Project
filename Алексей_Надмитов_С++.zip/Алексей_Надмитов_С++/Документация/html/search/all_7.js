var searchData=
[
  ['report_0',['Report',['../class_report.html',1,'Report'],['../class_report.html#ae3150817fcf4ebf814358baf5bd72e8f',1,'Report::Report()'],['../class_report.html#af1174f713b0421c12c955a245ddb04ef',1,'Report::Report(Report &amp;&amp;other) noexcept']]],
  ['run_1',['run',['../class_application.html#a214b296f3c9a4ba294bb12a68bb5e032',1,'Application']]]
];
