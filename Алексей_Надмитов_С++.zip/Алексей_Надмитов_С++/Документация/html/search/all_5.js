var searchData=
[
  ['logger_0',['Logger',['../class_logger.html',1,'Logger'],['../class_logger.html#a4f2ee02db1d03a83b6b9b43808e09f15',1,'Logger::Logger()']]]
];
