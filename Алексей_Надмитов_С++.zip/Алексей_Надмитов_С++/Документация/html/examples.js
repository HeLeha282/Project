var examples =
[
    [ "C:/Users/Lesha/Desktop/TestTaskKaspersky/Project/src/HashCalculator.h", "_c_1_2_users_2_lesha_2_desktop_2_test_task_kaspersky_2_project_2src_2_hash_calculator_8h-example.html", null ],
    [ "C:/Users/Lesha/Desktop/TestTaskKaspersky/Project/src/Logger.h", "_c_1_2_users_2_lesha_2_desktop_2_test_task_kaspersky_2_project_2src_2_logger_8h-example.html", null ]
];