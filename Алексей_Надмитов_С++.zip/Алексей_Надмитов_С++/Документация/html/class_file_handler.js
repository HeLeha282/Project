var class_file_handler =
[
    [ "FileHandler", "class_file_handler.html#a002d7b9a87f96f5c1b95eb010c0370df", null ],
    [ "processFile", "class_file_handler.html#afe18c3ce66c5a692f1b892021b74cdfa", null ]
];