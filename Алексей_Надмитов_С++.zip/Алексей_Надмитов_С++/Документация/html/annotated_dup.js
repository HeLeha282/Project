var annotated_dup =
[
    [ "Application", "class_application.html", "class_application" ],
    [ "Database", "class_database.html", "class_database" ],
    [ "DirectoryScanner", "class_directory_scanner.html", "class_directory_scanner" ],
    [ "FileHandler", "class_file_handler.html", "class_file_handler" ],
    [ "HashCalculator", "class_hash_calculator.html", null ],
    [ "Logger", "class_logger.html", "class_logger" ],
    [ "Report", "class_report.html", "class_report" ],
    [ "StringUtils", "class_string_utils.html", null ]
];