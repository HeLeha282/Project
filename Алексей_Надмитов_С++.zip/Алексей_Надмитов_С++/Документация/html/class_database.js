var class_database =
[
    [ "Database", "class_database.html#a5f8c545125372ea08993c724e4152c87", null ],
    [ "getVerdict", "class_database.html#afc9872234bd7addf49c8f408936318ff", null ]
];