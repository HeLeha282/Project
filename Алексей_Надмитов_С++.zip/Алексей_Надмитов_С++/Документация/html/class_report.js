var class_report =
[
    [ "Report", "class_report.html#ae3150817fcf4ebf814358baf5bd72e8f", null ],
    [ "Report", "class_report.html#af1174f713b0421c12c955a245ddb04ef", null ],
    [ "addError", "class_report.html#a3503fac691eb4ce848ac59f0eee09941", null ],
    [ "addFileProcessed", "class_report.html#af36d9a9fd37cbde87550a41bf2876fe2", null ],
    [ "addHealthy", "class_report.html#a2e4adab93eb5758c01c7e9b15189ae49", null ],
    [ "addInfected", "class_report.html#aac946350c5a68eabb8cde30e71e34c52", null ],
    [ "printReport", "class_report.html#a5ae9f5b055b4dd31b83f96fa95a929e5", null ],
    [ "setElapsedTime", "class_report.html#a67b26c288d0c6ba31e3c183458f6a040", null ]
];