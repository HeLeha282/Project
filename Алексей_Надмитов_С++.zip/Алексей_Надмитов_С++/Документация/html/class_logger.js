var class_logger =
[
    [ "Logger", "class_logger.html#a4f2ee02db1d03a83b6b9b43808e09f15", null ],
    [ "~Logger", "class_logger.html#acb668a9e186a25fbaad2e4af6d1ed00a", null ]
];